LanguageTool, a proof-reading tool for English, German, Polish,
French, Dutch, Russian and more languages

Copyright (C) 2005-2017 the LanguageTool community and Daniel Naber (www.danielnaber.de)

See https://www.languagetool.org for more information
