Serbian (Cyrillic) Hunspell Spellchecking Dictionary

OpenOffice.org 3 extension with autoupdate feature can be downloaded
from: http://extensions.services.openoffice.org/project/dict-sr

Based on dict-sr release 2010-08-18, Goran Rakic <grakic@devbase.net>

To send suggestions and contribute your improvements, please join our
public mailing list at http://groups.google.com/group/proverapisanja


License:
Serbian spellcheck dictionary is released under disjunctive tri-licence GNU
LGPL version 2.1 or later / MPL version 1.1 or later / GNU GPL version 2 or
later giving you the choice of one of the three sets of free software licensing
terms. You can also use the dictionary under the terms of Creative Commons
BY-SA 3.0 Unpored licence.
